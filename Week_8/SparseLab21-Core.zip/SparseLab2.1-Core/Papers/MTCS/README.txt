This set of Matlab (7.0) functions contain the code for generating 
the figures of the following paper:

"Multi-Task Compressive Sensing" 
Shihao Ji, David Dunson, and Lawrence Carin (Preprint, 2007)

The code is still in development stage. If you have any comments or bug reports, 
you are welcome to contact Shihao Ji at shji@ece.duke.edu.


Shihao Ji
Duke University, July 19, 2007

***************************************************************************
Distribution and use of this code is subject to the following agreement:

This Program is provided by Duke University and the authors as a service
to the research community. It is provided without cost or restrictions, 
except for the User's acknowledgement that the Program is provided on an 
"As Is" basis and User understands that Duke University and the authors 
make no express or implied warranty of any kind.  Duke University and the
authors specifically disclaim any implied warranty or merchantability or 
fitness for a particular purpose, and make no representations or warranties 
that the Program will not infringe the intellectual property rights of 
others. The User agrees to indemnify and hold harmless Duke University and
the authors from and against any and all liability arising out of User's 
use of the Program.
***************************************************************************




