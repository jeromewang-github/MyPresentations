function x = rhs( y )
x = y.rhs;
