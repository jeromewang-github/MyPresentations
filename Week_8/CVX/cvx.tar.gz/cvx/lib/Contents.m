% CVX: Internal functions and scripts.
%    This directory contains code that is meant for internal use by
%    the CVX system itself. Documentation of the functions in this
%    directory is more sparse and not intended for end users.
