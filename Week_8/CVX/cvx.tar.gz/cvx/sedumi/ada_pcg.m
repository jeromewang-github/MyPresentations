%A dummy file for Yalmip.
